# personal-rc
## My personal functions, aliases, and configuration files for ZSH and BASH.